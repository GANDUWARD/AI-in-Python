Datasets for KNN classifying.
